#ifndef _CODE4004_H
#define _CODE4004_H
/* code4004.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Intel 4004/4040                                             */
/*                                                                           */
/* Historie: 1.2.1997 Grundsteinlegung                                       */
/*                                                                           */
/*****************************************************************************/

extern void code4004_init(void);
#endif /* _CODE4004_H */
