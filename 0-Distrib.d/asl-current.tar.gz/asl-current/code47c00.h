#ifndef _CODE47C00_H
#define _CODE47C00_H
/* code47c00.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Toshiba TLCS-47(0(A))                                       */
/*                                                                           */
/* Historie: 30.12.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code47c00_init(void);
#endif /* _CODE47C00_H */
