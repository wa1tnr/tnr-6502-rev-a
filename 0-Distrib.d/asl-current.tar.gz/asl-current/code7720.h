#ifndef _CODE7720_H
#define _CODE7720_H
/* code7720.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* Makroassembler AS                                                         */
/*                                                                           */
/* Codegenerator NEC uPD7720                                                 */
/*                                                                           */
/* Historie: 30.  8.1998 Grundsteinlegung                                    */
/*                                                                           */
/*****************************************************************************/

extern void code7720_init(void);
#endif /* _CODE7720_H */
