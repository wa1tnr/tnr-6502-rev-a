#ifndef _CODE8X30X_H
#define _CODE8X30X_H
/* code8x30x.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Signetics 8X30x                                             */
/*                                                                           */
/* Historie: 25.6.1997 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void code8x30x_init(void);
#endif /* _CODE8X30X_H */
