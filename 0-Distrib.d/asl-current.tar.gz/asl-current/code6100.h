#ifndef _CODE6100_H
#define _CODE6100_H
/* code6100.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Intersil IM6100                                             */
/*                                                                           */
/*****************************************************************************/

extern void code6100_init(void);
#endif /* _CODE6100_H */
