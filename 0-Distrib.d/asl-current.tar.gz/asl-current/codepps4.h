#ifndef _CODEPPS4_H
#define _CODEPPS4_H
/* codepps4.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS                                                                        */
/*                                                                           */
/* Codegeneratormodul Rockwell PPS-4                                         */
/*                                                                           */
/*****************************************************************************/

extern void codepps4_init(void);
#endif /* _CODEPPS4_H */
