#ifndef _CODE3201X_H
#define _CODE3201X_H
/* code3201x.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator TMS3201x-Familie                                            */
/*                                                                           */
/* Historie: 28.11.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code3201x_init(void);
#endif /* _CODE3201X_H */
