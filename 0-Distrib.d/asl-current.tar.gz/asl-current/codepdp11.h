#ifndef _CODEPDP11_H
#define _CODEPDP11_H
/* codepdp11.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS                                                                        */
/*                                                                           */
/* Code Generator PDP-11                                                     */
/*                                                                           */
/*****************************************************************************/

extern void codepdp11_init(void);
#endif /* _CODEPDP11_H */
