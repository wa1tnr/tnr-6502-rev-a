#ifndef _CODENS32K_H
#define _CODENS32K_H
/* codens32k.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Code Generator National Semiconductor NS32000                             */
/*                                                                           */
/*****************************************************************************/

extern void codens32k_init(void);
#endif /* _CODENS32K_H */
