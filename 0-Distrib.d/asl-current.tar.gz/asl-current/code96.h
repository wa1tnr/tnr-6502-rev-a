#ifndef _CODE96_H
#define _CODE96_H
/* code96.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator MCS/96-Familie                                              */
/*                                                                           */
/* Historie: 10.11.1996                                                      */
/*                                                                           */
/*****************************************************************************/

extern void code96_init(void);
#endif /* _CODE96_H */
