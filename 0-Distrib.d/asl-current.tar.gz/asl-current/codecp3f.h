#ifndef _CODECP3F_H
#define _CODECP3F_H
/* codecp3f.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegeneratormodul Olympia CP-3F                                          */
/*                                                                           */
/*****************************************************************************/

extern void codecp3f_init(void);
#endif /* _CODECP3F_H */
