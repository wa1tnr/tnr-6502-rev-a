#ifndef _CODEKO09_H
#define _CODEKO09_H
/* codeko09.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Konami 052001                                               */
/*                                                                           */
/*****************************************************************************/

extern void codeko09_init(void);
#endif /* _CODEKO09_H */
