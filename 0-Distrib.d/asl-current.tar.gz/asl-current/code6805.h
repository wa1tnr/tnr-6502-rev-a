#ifndef _CODE6805_H
#define _CODE6805_H
/* code6805.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator 68(HC)05/08                                                 */
/*                                                                           */
/* Historie:  9.10.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code6805_init(void);
#endif /* _CODE6805_H */
