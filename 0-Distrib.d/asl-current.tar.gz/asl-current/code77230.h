#ifndef _CODE77230_H
#define _CODE77230_H
/* code77230.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* Makroassembler AS                                                         */
/*                                                                           */
/* Codegenerator NEC uPD77230                                                */
/*                                                                           */
/* Historie: 13. 9.1998 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code77230_init(void);
#endif /* _CODE77230_H */
