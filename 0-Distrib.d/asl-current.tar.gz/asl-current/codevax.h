#ifndef _CODEVAX_H
#define _CODEVAX_H
/* codepdp11.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS                                                                        */
/*                                                                           */
/* Code Generator VAX                                                        */
/*                                                                           */
/*****************************************************************************/

extern void codevax_init(void);
#endif /* _CODEVAX_H */
