#ifndef _CODEZ8_H
#define _CODEZ8_H
/* codez8.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Zilog Z8                                                    */
/*                                                                           */
/* Historie: 8.11.1996 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void codez8_init(void);
#endif /* _CODEZ8_H */
