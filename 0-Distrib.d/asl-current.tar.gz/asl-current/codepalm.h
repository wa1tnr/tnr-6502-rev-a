#ifndef _CODEPALM_H
#define _CODEPALM_H
/* codepdp11.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS                                                                        */
/*                                                                           */
/* Code Generator PALM                                                       */
/*                                                                           */
/*****************************************************************************/

extern void codepalm_init(void);

#endif /* _CODEPALM_H */
