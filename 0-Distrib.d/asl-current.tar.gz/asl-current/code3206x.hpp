#ifndef _CODE3206X_HPP
#define _CODE3206X_HPP

/* Declare this in a header file so CLang++ does not complain
   about unused inline functions: */

# include "cppops.h"
DefCPPOps_Enum(TUnit)

#endif /* _CODE3206X_HPP */
