#ifndef _CODERX_H
#define _CODERX_H
/* coderx.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Renesas RX                                                  */
/*                                                                           */
/*****************************************************************************/

extern void coderx_init(void);
#endif /* _CODERX_H */
