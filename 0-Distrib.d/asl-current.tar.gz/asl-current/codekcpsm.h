/* codekcpsm.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator xilinx kcpsm                                                */
/*                                                                           */
/* Historie: 27.02.2003 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void codekcpsm_init(void);
