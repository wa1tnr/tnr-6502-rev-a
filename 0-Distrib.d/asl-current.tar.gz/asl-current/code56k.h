#ifndef _CODE56K_H
#define _CODE56K_H
/* code56k.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* AS-Codegeneratormodul fuer die DSP56K-Familie                             */
/*                                                                           */
/* Historie: 10. 6.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code56k_init(void);
#endif /* _CODE56K_H */
