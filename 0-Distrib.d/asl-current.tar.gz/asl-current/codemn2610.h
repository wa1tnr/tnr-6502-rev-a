#ifndef _CODEMN2610_H
#define _CODEMN2610_H
/* codemn2610.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS, C-Version                                                             */
/*                                                                           */
/* Code Generator for MN161x Processor - alternate version                   */
/*                                                                           */
/*****************************************************************************/

extern void codemn2610_init(void);
#endif /* _CODEMN2610_H */
