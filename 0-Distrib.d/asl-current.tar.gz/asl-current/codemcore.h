#ifndef _CODEMCORE_H
#define _CODEMCORE_H
/* codemcore.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator MCORE-Familie                                               */
/*                                                                           */
/* Historie:  31.1.1998 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void codemcore_init(void);
#endif /* _CODEMCORE_H */
