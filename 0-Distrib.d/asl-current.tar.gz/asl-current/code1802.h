#ifndef _CODE1802_H
#define _CODE1802_H
/* code1802.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS                                                                        */
/*                                                                           */
/* Code Generator for Intersil 1802                                          */
/*                                                                           */
/* History: 27. 1.2001 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void code1802_init(void);
#endif /* _CODE1802_H */
