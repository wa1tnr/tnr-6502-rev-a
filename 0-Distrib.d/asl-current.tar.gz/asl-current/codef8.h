#ifndef _CODEF8_H
#define _CODEF8_H
/* codef8.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegeneratormodul Fairchild F8                                           */
/*                                                                           */
/*****************************************************************************/

extern void codef8_init(void);
#endif /* _CODEF8_H */
