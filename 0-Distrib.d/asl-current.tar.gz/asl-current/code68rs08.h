#ifndef _CODE68RS08_H
#define _CODE68RS08_H
/* code68rs08.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator 68RS08                                                      */
/*                                                                           */
/* Historie: 2006-06-02 initial version based on code6805.h                  */
/*                                                                           */
/*****************************************************************************/

extern void code68rs08_init(void);
#endif /* _CODE68RS08_H */
