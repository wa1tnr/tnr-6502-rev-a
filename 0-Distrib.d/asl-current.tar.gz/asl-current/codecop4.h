#ifndef _CODECOP4_H
#define _CODECOP4_H
/* codecop4.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegeneratormodul COP4-Familie                                           */
/*                                                                           */
/*****************************************************************************/

extern void codecop4_init(void);
#endif /* _CODECOP4_H */
